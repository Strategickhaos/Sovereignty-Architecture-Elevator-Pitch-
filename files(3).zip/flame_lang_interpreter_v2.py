#!/usr/bin/env python3
"""
🔥 FlameLang Interpreter v2.0
Strategickhaos Sovereign Symbolic Language Runtime

Usage:
    python flame_lang_interpreter.py
    
Commands:
    <symbol>     - Execute glyph by symbol (e.g., AE1, FL1)
    [code]       - Execute by binding code (e.g., [999], [777])
    list         - Show all available glyphs
    search <q>   - Search glyphs by name/function
    freq <hz>    - Filter by frequency
    help         - Show this help
    exit         - Shutdown interpreter
"""

import csv
import os
import sys
from pathlib import Path
from datetime import datetime

# === CONFIGURATION ===
GLYPH_TABLE_PATH = Path(__file__).parent / 'glyph_table.csv'
VOW_MONITOR_PATH = Path.home() / 'Strategickhaos' / 'VowMonitor'
LOG_PATH = Path.home() / 'StrategickhaosLogs'

# === ANSI COLORS ===
class C:
    FIRE = '\033[91m'
    GOLD = '\033[93m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    PURPLE = '\033[95m'
    RESET = '\033[0m'
    BOLD = '\033[1m'

def colorize(text, color):
    return f"{color}{text}{C.RESET}"

# === GLYPH LOADER ===
def load_glyphs(path=GLYPH_TABLE_PATH):
    """Load glyph table from CSV"""
    try:
        with open(path, newline='', encoding='utf-8') as file:
            reader = csv.DictReader(file)
            glyphs = list(reader)
            print(colorize(f"[✓] Loaded {len(glyphs)} glyphs from {path}", C.GREEN))
            return glyphs
    except FileNotFoundError:
        print(colorize(f"[✗] Could not locate: {path}", C.FIRE))
        print(colorize("    Creating default glyph table...", C.GOLD))
        create_default_table(path)
        return load_glyphs(path)

def create_default_table(path):
    """Create default glyph table if missing"""
    default_glyphs = [
        ['Symbol', 'Glyph Name', 'Frequency', 'Function', 'Binding Code'],
        ['AE1', 'Aether Prime', '432Hz', 'Initialize sovereign shell', '[001]'],
        ['FL1', 'Flame Ignite', '528Hz', 'FlameLang boot sequence', '[100]'],
        ['RS1', 'ReflexShell Activate', '639Hz', 'Bash/WSL hemisphere init', '[200]'],
        ['VW1', 'Vow Monitor', '417Hz', 'Sovereignty log active', '[700]'],
        ['GR1', 'Glyphos Resonance', '999Hz', 'Full resonance cascade', '[999]'],
    ]
    os.makedirs(path.parent, exist_ok=True)
    with open(path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerows(default_glyphs)

# === GLYPH EXECUTION ===
def execute_glyph(command, glyphs):
    """Find and execute a glyph by symbol or binding code"""
    command = command.strip()
    match = None
    
    for glyph in glyphs:
        # Match by symbol (case-insensitive)
        if glyph['Symbol'].lower() == command.lower():
            match = glyph
            break
        # Match by binding code (with or without brackets)
        code = command.strip('[]')
        if glyph['Binding Code'].strip('[]') == code:
            match = glyph
            break
        # Partial match on binding code
        if glyph['Binding Code'].lower().startswith(f"[{code}"):
            match = glyph
            break

    if match:
        print()
        print(colorize("╔══════════════════════════════════════════╗", C.FIRE))
        print(colorize("║       🔥 GLYPH EXECUTED                  ║", C.FIRE))
        print(colorize("╠══════════════════════════════════════════╣", C.FIRE))
        print(colorize(f"║ Symbol       : {match['Symbol']:<25}║", C.GOLD))
        print(colorize(f"║ Name         : {match['Glyph Name']:<25}║", C.GOLD))
        print(colorize(f"║ Frequency    : {match['Frequency']:<25}║", C.CYAN))
        print(colorize(f"║ Function     : {match['Function'][:25]:<25}║", C.GREEN))
        print(colorize(f"║ Binding Code : {match['Binding Code']:<25}║", C.PURPLE))
        print(colorize("╠══════════════════════════════════════════╣", C.FIRE))
        print(colorize("║ → Neural Sync complete. Resonance achieved.║", C.GREEN))
        print(colorize("╚══════════════════════════════════════════╝", C.FIRE))
        print()
        
        # Log execution
        log_execution(match)
        return match
    else:
        print(colorize("[⚠] Glyph not found or invalid command.", C.GOLD))
        print(colorize("    Type 'list' to see available glyphs.", C.CYAN))
        return None

def log_execution(glyph):
    """Log glyph execution to sovereignty log"""
    try:
        LOG_PATH.mkdir(parents=True, exist_ok=True)
        log_file = LOG_PATH / f"flamelang_{datetime.now().strftime('%Y%m%d')}.log"
        with open(log_file, 'a', encoding='utf-8') as f:
            timestamp = datetime.now().isoformat()
            f.write(f"[{timestamp}] EXEC: {glyph['Symbol']} | {glyph['Glyph Name']} | {glyph['Binding Code']}\n")
    except Exception:
        pass  # Silent fail on log errors

# === COMMANDS ===
def list_glyphs(glyphs):
    """Display all available glyphs"""
    print()
    print(colorize("╔═══════════════════════════════════════════════════════════════════════════╗", C.FIRE))
    print(colorize("║                        🔥 FLAMELANG GLYPH TABLE                           ║", C.FIRE))
    print(colorize("╠════════╦═══════════════════════╦══════════╦════════════════════════════════╣", C.FIRE))
    print(colorize("║ Symbol ║ Name                  ║ Freq     ║ Binding Code                   ║", C.GOLD))
    print(colorize("╠════════╬═══════════════════════╬══════════╬════════════════════════════════╣", C.FIRE))
    
    for g in glyphs:
        sym = g['Symbol'][:6].ljust(6)
        name = g['Glyph Name'][:21].ljust(21)
        freq = g['Frequency'][:8].ljust(8)
        code = g['Binding Code'][:30].ljust(30)
        print(f"║ {sym} ║ {name} ║ {freq} ║ {code} ║")
    
    print(colorize("╚════════╩═══════════════════════╩══════════╩════════════════════════════════╝", C.FIRE))
    print()

def search_glyphs(query, glyphs):
    """Search glyphs by name or function"""
    query = query.lower()
    matches = [g for g in glyphs if 
               query in g['Glyph Name'].lower() or 
               query in g['Function'].lower() or
               query in g['Symbol'].lower()]
    
    if matches:
        print(colorize(f"\n[🔍] Found {len(matches)} matches for '{query}':\n", C.CYAN))
        for g in matches:
            print(f"  {colorize(g['Symbol'], C.GOLD)} | {g['Glyph Name']} | {colorize(g['Binding Code'], C.PURPLE)}")
        print()
    else:
        print(colorize(f"[⚠] No glyphs found matching '{query}'", C.GOLD))

def filter_by_freq(freq, glyphs):
    """Filter glyphs by frequency"""
    matches = [g for g in glyphs if freq.lower() in g['Frequency'].lower()]
    if matches:
        print(colorize(f"\n[🎵] Glyphs at {freq}:\n", C.CYAN))
        for g in matches:
            print(f"  {colorize(g['Symbol'], C.GOLD)} | {g['Glyph Name']} | {g['Function'][:40]}")
        print()
    else:
        print(colorize(f"[⚠] No glyphs at frequency '{freq}'", C.GOLD))

def show_help():
    """Display help information"""
    print(colorize("""
╔═══════════════════════════════════════════════════════════════╗
║                 🔥 FLAMELANG INTERPRETER HELP                 ║
╠═══════════════════════════════════════════════════════════════╣
║ COMMANDS:                                                     ║
║   <symbol>      Execute glyph (e.g., AE1, FL1, GR1)          ║
║   [code]        Execute by binding code (e.g., [999])        ║
║   list          Show all available glyphs                     ║
║   search <q>    Search by name/function                       ║
║   freq <hz>     Filter by frequency (e.g., freq 528)         ║
║   help          Show this help                                ║
║   exit          Shutdown interpreter                          ║
╠═══════════════════════════════════════════════════════════════╣
║ EXAMPLES:                                                     ║
║   glyph> AE1              # Execute Aether Prime             ║
║   glyph> [999]            # Execute Glyphos Resonance        ║
║   glyph> search nova      # Find Nova-related glyphs         ║
║   glyph> freq 528         # List all 528Hz glyphs            ║
╚═══════════════════════════════════════════════════════════════╝
""", C.CYAN))

# === MAIN INTERPRETER ===
def interpreter():
    """Main REPL loop"""
    print()
    print(colorize("╔═══════════════════════════════════════════════════════════════╗", C.FIRE))
    print(colorize("║         🔥 FLAMELANG INTERPRETER v2.0 ACTIVATED 🔥            ║", C.FIRE))
    print(colorize("║         Strategickhaos Sovereign Symbolic Runtime             ║", C.GOLD))
    print(colorize("╚═══════════════════════════════════════════════════════════════╝", C.FIRE))
    print()
    
    glyphs = load_glyphs()
    if not glyphs:
        print(colorize("[✗] No glyphs loaded. Exiting.", C.FIRE))
        return

    print(colorize("Type a glyph symbol or 'help' for commands. 'exit' to close.\n", C.CYAN))

    while True:
        try:
            cmd = input(colorize("glyph> ", C.FIRE)).strip()
        except (EOFError, KeyboardInterrupt):
            print(colorize("\n[FlameLang] Interrupted. Shutting down.", C.GOLD))
            break
            
        if not cmd:
            continue
        
        cmd_lower = cmd.lower()
        
        if cmd_lower == 'exit':
            print(colorize("[FlameLang] Neural Sync terminated. Sovereignty preserved. 🔥", C.GREEN))
            break
        elif cmd_lower == 'help':
            show_help()
        elif cmd_lower == 'list':
            list_glyphs(glyphs)
        elif cmd_lower.startswith('search '):
            search_glyphs(cmd[7:], glyphs)
        elif cmd_lower.startswith('freq '):
            filter_by_freq(cmd[5:], glyphs)
        else:
            execute_glyph(cmd, glyphs)

# === ENTRY POINT ===
if __name__ == "__main__":
    interpreter()
